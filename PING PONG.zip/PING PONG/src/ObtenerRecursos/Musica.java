/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ObtenerRecursos;

import java.applet.AudioClip;

/**
 *
 * @author Melysa Granados, Krishna Leal 
 */
public class Musica {
    
    public AudioClip getMusica(String direccion) {
        return java.applet.Applet.newAudioClip(getClass().getResource(direccion));
    }
   
    
}
