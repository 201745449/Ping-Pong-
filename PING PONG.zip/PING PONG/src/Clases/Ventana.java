/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import control.MotordeGraficos;
import javax.swing.JFrame;


/**
 *
 * @author Melysa Granados, Krishna Leal 
 */
public class Ventana extends JFrame{
    TableroJuego canvas;
    pelota p = new pelota();

    public Ventana() {
        setTitle("Pong");
        setSize(800, 500);
        setLocationRelativeTo(null);
        setResizable(false);
        canvas = new TableroJuego();
        add(canvas);

        addKeyListener(new Teclado());
        new MotordeGraficos(canvas).start();
        
    }
    
}
